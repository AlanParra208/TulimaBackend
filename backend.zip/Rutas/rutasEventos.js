const express = require('express');
const app = express();
const { body, param, validateRequest } = require('../Middlewares/validator');
const { verificarToken } = require('../Middlewares/middleware'); // <-- FALTABA
const prisma = require('../config.db');

// GET público — para turistas
app.get('/eventos', async (req, res) => {
  try {
    const eventos = await prisma.evento.findMany({
      where: { activo: true },
      include: { municipio: true }
    });
    res.status(200).json(eventos);
  } catch (error) {
    console.error('Error al consultar eventos:', error);
    res.status(500).json({ error: 'Error al obtener eventos' });
  }
});

// GET solo los del proveedor autenticado
app.get('/eventos/mios', verificarToken, async (req, res) => {
  try {
    const eventos = await prisma.evento.findMany({
      where: { id_usuario: req.usuarioId },
      include: { municipio: true }
    });
    res.status(200).json(eventos);
  } catch (error) {
    console.error('Error al consultar eventos del proveedor:', error);
    res.status(500).json({ error: 'Error al obtener tus eventos' });
  }
});

// GET todos — para admin
app.get('/eventos/admin/todos', verificarToken, async (req, res) => {
  try {
    if (req.user?.rol !== 'admin') {
      return res.status(403).json({ error: 'Acceso restringido a administradores.' });
    }
    const eventos = await prisma.evento.findMany({
      include: { municipio: true }
    });
    res.status(200).json(eventos);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener eventos' });
  }
});

// GET por ID
app.get(
  '/eventos/:id',
  [param('id').isInt().withMessage('id debe ser un número entero')],
  validateRequest,
  async (req, res) => {
    const { id } = req.params;
    try {
      const evento = await prisma.evento.findFirst({
        where: { id_evento: Number(id), activo: true },
        include: { municipio: true }
      });
      if (!evento) return res.status(404).json({ error: 'Evento no encontrado' });
      res.status(200).json(evento);
    } catch (error) {
      res.status(500).json({ error: 'Error al obtener el evento' });
    }
  }
);

// POST — crear evento
app.post(
  '/eventos',
  verificarToken,
  [
    body('nombre_Evento').trim().notEmpty().withMessage('nombre_Evento es obligatorio').isLength({ max: 50 }),
    body('numero_Calle').isInt().withMessage('numero_Calle es obligatorio'),
    body('nombre_Calle').trim().notEmpty().isLength({ max: 50 }),
    body('codigoPostal').isInt().withMessage('codigoPostal es obligatorio'),
    body('id_municipio').isInt().withMessage('id_municipio es obligatorio'),
    body('pueblo').optional({ nullable: true }).isString().isLength({ max: 50 }).withMessage('pueblo inválido'),
    body('tipoEvento').optional().isString().isLength({ max: 50 }),
    body('fechaInicio').notEmpty().withMessage('fechaInicio es obligatoria'),
    body('fechaTermino').notEmpty().withMessage('fechaTermino es obligatoria'),
    body('imagen').optional().isString(),
    body('latitud').optional({ nullable: true }).isFloat({ min: -90, max: 90 }).withMessage('latitud inválida'),
    body('longitud').optional({ nullable: true }).isFloat({ min: -180, max: 180 }).withMessage('longitud inválida'),
  ],
  validateRequest,
  async (req, res) => {
    try {
      const yaTieneEvento = await prisma.evento.findFirst({ where: { id_usuario: req.usuarioId } });
      if (yaTieneEvento) {
        return res.status(400).json({ error: 'Ya tienes un evento registrado. Solo puedes tener un negocio por cuenta.' });
      }

      const {
        nombre_Evento, numero_Calle, nombre_Calle,
        codigoPostal, id_municipio, pueblo, tipoEvento, fechaInicio,
        fechaTermino, imagen, latitud, longitud
      } = req.body;

      const nuevoEvento = await prisma.evento.create({
        data: {
          nombre_Evento,
          numero_Calle: Number(numero_Calle),
          nombre_Calle,
          codigoPostal: Number(codigoPostal),
          id_municipio: Number(id_municipio),
          pueblo,
          tipoEvento,
          fechaInicio: new Date(fechaInicio),
          fechaTermino: new Date(fechaTermino),
          imagen,
          latitud: latitud ?? null,
          longitud: longitud ?? null,
          id_usuario: req.usuarioId, 
          activo: true,             
        }
      });
      res.status(201).json(nuevoEvento);
    } catch (error) {
      console.error('Error al crear evento:', error);
      res.status(500).json({ error: 'Error al crear el evento' });
    }
  }
);

// PUT — actualizar evento
app.put(
  '/eventos/:id',
   verificarToken,
  [
    param('id').isInt().withMessage('id debe ser un número entero'),
    body('nombre_Evento').optional().trim().isLength({ max: 50 }),
    body('numero_Calle').isInt().withMessage('numero_Calle es obligatorio'),
    body('nombre_Calle').trim().notEmpty().isLength({ max: 50 }),
    body('codigoPostal').isInt().withMessage('codigoPostal es obligatorio'),
    body('id_municipio').isInt().withMessage('id_municipio es obligatorio'),
    body('pueblo').optional({ nullable: true }).isString().isLength({ max: 50 }).withMessage('pueblo inválido'),
    body('tipoEvento').optional().isString().isLength({ max: 50 }),
    body('fechaInicio').optional(),
    body('fechaTermino').optional(),
    body('activo').optional().isBoolean(),
    body('imagen').optional().isString(),
    body('latitud').optional({ nullable: true }).isFloat({ min: -90, max: 90 }).withMessage('latitud inválida'),
    body('longitud').optional({ nullable: true }).isFloat({ min: -180, max: 180 }).withMessage('longitud inválida'),
  ],
  validateRequest,
  async (req, res) => {
    const { id } = req.params;
    try {
      const {
        nombre_Evento, numero_Calle, nombre_Calle,
        codigoPostal, id_municipio, pueblo, tipoEvento,
        fechaInicio, fechaTermino, activo, imagen,
        latitud, longitud
      } = req.body;

      const data = {};
      if (nombre_Evento !== undefined) data.nombre_Evento = nombre_Evento;
      if (numero_Calle !== undefined) data.numero_Calle = Number(numero_Calle);
      if (nombre_Calle !== undefined) data.nombre_Calle = nombre_Calle;
      if (codigoPostal !== undefined) data.codigoPostal = Number(codigoPostal);
      if (id_municipio !== undefined) data.id_municipio = Number(id_municipio);
      if (pueblo !== undefined) data.pueblo = pueblo;
      if (tipoEvento !== undefined) data.tipoEvento = tipoEvento;
      if (fechaInicio !== undefined) data.fechaInicio = new Date(fechaInicio);
      if (fechaTermino !== undefined) data.fechaTermino = new Date(fechaTermino);
      if (activo !== undefined) data.activo = activo;
      if (imagen !== undefined) data.imagen = imagen;
      if (latitud !== undefined) data.latitud = latitud;
      if (longitud !== undefined) data.longitud = longitud;

      const eventoActualizado = await prisma.evento.update({
        where: { id_evento: Number(id) },
        data
      });
      res.status(200).json(eventoActualizado);
    } catch (error) {
      console.error('Error al actualizar evento:', error);
      res.status(500).json({ error: 'Error al actualizar el evento' });
    }
  }
);


app.delete(
  '/eventos/:id',
   verificarToken,
  [param('id').isInt().withMessage('id debe ser un número entero')],
  validateRequest,
  async (req, res) => {
    const { id } = req.params;
    try {
      await prisma.evento.update({
        where: { id_evento: Number(id) },
        data: { activo: false },
      });
      res.status(200).json({ message: 'Evento desactivado correctamente' });
    } catch (error) {
      console.error('Error al desactivar evento:', error);
      if (error.code === 'P2025') {
        return res.status(404).json({ error: 'El evento no existe.' });
      }
      res.status(500).json({ error: 'Error al desactivar el evento' });
    }
  }
);

module.exports = app;